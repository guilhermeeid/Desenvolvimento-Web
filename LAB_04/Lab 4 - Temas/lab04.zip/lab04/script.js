document.getElementById('botao').addEventListener('click', function() {
    document.body.classList.toggle('modo_escuro');
});